### Descrição

Insira aqui a descrição da funcionalidade, mencione issues e outras coisas ligadas a este Pull Request.

### Revisão

- [ ] Check if ...
- [ ] ...

### Checklist pré-merge

- [ ] Verificar se esse Pull Request está alinhado com um rebase da master
- [ ] Existe algo à acrescentar na documentação?
- [ ] Fazer Squash em commits desnecessários

### Screenshots

| Antes | Depois |
| ----- | ------ |
| Insira screenshots aqui... | Insira screenshots aqui... |
